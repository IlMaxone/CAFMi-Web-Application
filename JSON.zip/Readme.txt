Queste cartelle servono a far funzionare il JSON della webapp CAFMi
Per poter sfruttare al 100% JSON fai questi passaggi:
- apri esplora risorse e vai su C:\
- estrai il contenuto di questo zip in C:\
- assicurati di avere la cartella JSON in C:\
ora il gioco è fatto e hai integrato tutta le cartelle necessarie al linguaggio JSON per funzionare,
i rispettivi file si creeranno da soli nelle cartelle, puoi scegliere se tenerti le liste di base già qui dento oppure cancellare tutti i file